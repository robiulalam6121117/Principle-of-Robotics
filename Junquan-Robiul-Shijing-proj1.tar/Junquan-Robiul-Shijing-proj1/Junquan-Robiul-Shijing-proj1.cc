/*
 *  Project1 
 *  
 *
 *  Modified the sample code provieded by professr Simon Parsons
 *  to  make  the  robot move in a squre routa. 
 *
 *  Modified:    Junquan Wu, Robiul Alam, Shijing Zheng
 *                Group 13 
 *  Date:        9th September 2020
 *  
 */

#include <iostream>
#include <cstdlib>
#include <libplayerc++/playerc++.h>

int main(int argc, char *argv[])
{  
  using namespace PlayerCc;  

  // Set up proxy. Proxies are the datastructures that Player uses to
  // talk to the simulator and the real robot.

  PlayerClient    robot("localhost");  
  Position2dProxy pp(&robot,0);       // The 2D proxy is used to send 
                                      // motion commands.

  int timer = 0;                      // A crude way to time what we do
                                      // is to count.

  bool IsMotorEnable = true;          // Sign the signal  to end
				      // the loop after the roomba  
                                      // stop
  // Allow the program to take charge of the motors (take care now)
  pp.SetMotorEnable(true);

  // Control loop
  while(IsMotorEnable) 
    {    
      double turnrate, speed;

      // Increment the counter.

      timer++;

      // Read from the proxies.
      robot.Read();

      if(timer < 30){
	speed = 1;
	turnrate = 0;
      }
      else
      if((timer >= 30) && (timer < 60)){
	speed = 0;
	turnrate = -0.525;
      }
      else
      if((timer < 90)){
	speed = 1;
	turnrate = 0;
      }
      else 
      if((timer >= 90) && (timer < 120)){
	speed = 0;
	turnrate = -0.525;
      }
      else
      if((timer < 150)){
	speed = 1;
	turnrate = 0;
      }
      else 
      if((timer >= 150) && (timer < 180)){
	speed = 0;
	turnrate = -0.525;
      }
      else
      if((timer < 210)){
	speed = 1;
	turnrate = 0;
      }	
      else
      {
	speed = 0;
        turnrate = 0;
        IsMotorEnable = false;
      }		
       
      // Print out what we decided to do?
      std::cout << "Speed: " << speed << std::endl;      
      std::cout << "Turn rate: " << turnrate << std::endl << std::endl;

      // Send the motion commands that we decided on to the robot.
      pp.SetSpeed(speed, turnrate); 
      pp.SetMotorEnable(false); 
    }    	
  
}


