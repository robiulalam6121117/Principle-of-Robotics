/*
 *  Project6
 *
 *  Modified:    Junquan Wu, Robiul Alam, Shijing Zheng
 *                Group 13
 *  Date:       11th December 2020
 *
 */
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;

public class MakePlan{
  final static int size = 32;
  final static int initY = 4, initX = 28, goalY = 29, goalX = 3;
    public static void main (String[]args) throws Exception {
        int[][] map = readMap();
        printMap(map);
        int[][] planedMap  = makePlan(map);
        outputMap(planedMap);
        System.out.println("\n");
        printMap(planedMap);
        int[] totalWayPoints = findWayPoints(planedMap);
        planPoint(totalWayPoints);
    }
//read map from map.txt
    static int[][] readMap()throws Exception{
      int[][] map = new int[size][size];
      Scanner s = new Scanner(new File("map.txt"));
      for(int i = 0; i< size; i++){
        for (int j = 0; j<size; j++ ){
          int num = s.nextInt();
          if (num == 1) map[i][j] = -1;
          if (num == 0) map[i][j] = -2;
        }
      }
      return map;
    }
    //print map from map
    static void printMap(int[][] map){
      for(int i = 0; i< size; i++){
        for (int j = 0; j<size; j++ ){
        if(map[i][j] >9 || map[i][j] == -1)  System.out.print(" " +map[i][j]);
        else if(map[i][j] == -2) System.out.print("  " + 0);
        else  System.out.print("  " + map[i][j]);
        }
        System.out.println();
      }
    }


    static int[][]  makePlan(int[][] map){
      map = increaseBoundary(map);
      System.out.println();
      printMap(map);
      int counter = 0;
      map[goalX][goalY] = 0;
      while (map[initX][initY] == -2){
        for(int i = 0; i<size; i++){
          for (int j = 0; j<size ; j++ ) {
            if (map[i][j] == counter){
              if(i>0 && map[i-1][j] == -2) map[i-1][j] = counter +1;
              if(i<size-1 && map[i+1][j] == -2) map[i+1][j] = counter +1;
              if(j>0 && map[i][j-1] == -2) map[i][j-1] = counter +1;
              if(j<size-1 && map[i][j+1] == -2) map[i][j+1] = counter +1;
              }
            }
          }
          counter++;
        }
        for(int i = 0; i< size; i++){
          for (int j = 0; j<size; j++ ){
            if(map[i][j] == -2) map[i][j] =-1;
          }
        }
      return map;
    }

    static int[][] increaseBoundary(int[][] map){
      //increase the left and up boundary
      for(int i = 0; i<size; i++){
        for (int j = 0; j<size ; j++ ) {
          if(map[j][i] == -1){
            if(i>0 && i <size-1 &&  j>0 && j <size-1 ){
              if(map[j-1][i] != -1) map[j-1][i]  = -1;
              if(map[j][i-1] != -1) map[j][i-1]  = -1;
            }
          }
        }
      }
      //increase the right and down boundary
      for(int i = size-1; i>0; i--){
        for (int j = size-1; j>0 ; j-- ) {
          if(map[j][i] == -1){
            if(i>0 && i <size-1 &&  j>0 && j <size-1 ){
              if(map[j][i+1] != -1) map[j][i+1]  = -1;
              if(map[j+1][i] != -1) map[j+1][i]  = -1;
            }
          }
        }
      }
      return map;
    }
    //out put map into map-out.txt
    static void outputMap(int[][] map)throws Exception{
      PrintWriter pw = new PrintWriter("map-out.txt");
      for(int i = 0; i< size; i++){
        for (int j = 0; j<size; j++ ){
        if(map[i][j] >9 || map[i][j] == -1)  pw.print(" " +map[i][j]);
        else  pw.print("  " + map[i][j]);
        }
        pw.println();
      }
      pw.close();
    }
    //get all the points of the path from init point to the goal points
    static int[] findWayPoints(int[][] map){
      int counter = -1;
      int y = initY;
      int x = initX;
      int total = map[x][y];
      Boolean hadPoint = false;
      int[] wayPoints = new int[total*2] ;
      for(int i = total-1; i>=0 ; --i){
        int up = y + 1;
        int down = y -1;
        int left = x +1;
        int right = x-1;
        if( map[left][y] == i && !hadPoint) {
            x++;
            wayPoints[++counter] = y;
            wayPoints[++counter] = x;
            hadPoint = true;
        }
        if(  map[right][y] == i && !hadPoint) {
            x--;
            wayPoints[++counter] = y;
            wayPoints[++counter] = x;
            hadPoint = true;
        }
        if(map[x][down] == i && !hadPoint) {
            y--;
            wayPoints[++counter] = y;
            wayPoints[++counter] = x;
            hadPoint = true;
        }
        if( map[x][up] == i && !hadPoint) {
            y++;
            wayPoints[++counter] = y;
            wayPoints[++counter] = x;
            hadPoint = true;

        }
        hadPoint = false;
      System.out.print(" ("+y+" " +x + ") " );
      }
      return wayPoints;
    }
//ount put the truning point from total way points to plan-out.txt
   static void planPoint(int[] points)throws Exception{
      PrintWriter pw = new PrintWriter("plan-out.txt");
      int x1, y1, x2, y2, x3, y3;
      for(int i = 0; i<points.length - 5; i= i+2){
         x1 = points[i];
         y1 = points[i+1];
         x2 = points[i+2];
         y2 = points[i+3];
         x3 = points[i+4];
         y3 = points[i+5];
        if(x1 == x2 && x2 != x3 ) {
          pw.print((float)x2 - 22.5+" "); //adjust the x coodr.
          pw.print((float)y2+ 3.5+" ");  //adjust the y coodr.
        }else if(y1 == y2 && y2 != y3 ){
          pw.print((float)x2 - 22.5+" "); //adjust the x coodr.
          pw.print((float)y2 + 3.5+" ");  //adjust the y coodr.
        }
      }
      //out put the last points
      pw.print((float)points[points.length -2] - 22.5+" ");
      pw.print((float)points[points.length -1]+ 3.5+" ");
      pw.close();
    }
}
