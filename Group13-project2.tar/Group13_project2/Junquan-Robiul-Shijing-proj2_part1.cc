/*
 *  Project2_part1_wall_world
 *  
 *
 *  Modified the sample code provieded by professr Simon Parsons
 *
 *  Modified:    Junquan Wu, Robiul Alam, Shijing Zheng
 *                Group 13 
 *  Date:       5th Obtober 2020
 *  
 */

#include <iostream>
#include <cstdlib>
#include <libplayerc++/playerc++.h>

int main(int argc, char *argv[])
{  
  using namespace PlayerCc;  

  // Set up proxies. Proxies are the datastructures that Player uses to
  // talk to the simulator and the real robot.

  PlayerClient    robot("localhost");  
  BumperProxy     bp(&robot,0);       // The bumper proxy reads from the
                                      // bumpers.
  Position2dProxy pp(&robot,0);       // The 2D proxy reads odometry from 
                                      // the robot and sends motion commands.

  // Allow the program to take charge of the motors (take care now)
  pp.SetMotorEnable(true);

   double turnrate_P = dtor(30);
   double turnrate_N = dtor(-30);
   double speed_P = 0.5;
   double speed_N = -0.5;

  // Control loop
  while(true) 
    {    
      double turnrate, speed;

      // Read from the proxies.
      robot.Read();

      // What does odometry tell us? In other words, how far do we
      // think we have gone?
      std::cout << "x: " << pp.GetXPos()  << std::endl;
      std::cout << "y: " << pp.GetYPos()  << std::endl;
      std::cout << "a: " << pp.GetYaw()  << std::endl;


      // Print out what the bumpers tell us:
      std::cout << "Left  bumper: " << bp[0] << std::endl;
      std::cout << "Right bumper: " << bp[1] << std::endl;
      
      // If  the robot get stall than it will randomly move and turn.
      if(pp.GetStall())
      {
       if(rand()%2 > 0){
	    turnrate = turnrate_P;
	  }
	  else {
	    turnrate = turnrate_N;
	  } 
	if(rand()%2 > 0){
	    speed=speed_N;
	  }
	  else {
	    speed=speed_P;
	  }
      }
      
      // If either bumper is pressed, go backwards. Depending on the
      // combination of bumpers that are pressed, turn some also,
      // trying to turn away from the point of contact. 
      //
      // Otherwise just go forwards
      else if(bp[0] || bp[1]){

	speed=0.05;

	// Left bumper in contact, right bumper not in contact. Turn
	// to the right.  
	//
	// dtor converts from degrees to radians.
	if (bp[0] && !bp[1]) {  
	  turnrate=turnrate_N;  
	}

	// Left bumper not in contact, right bumper in contact. Turn
	// to the left
	if (!bp[0] && bp[1]) {
	  turnrate=turnrate_P;
	}

	// Both left and right bumpers in contact. Make a random
	// choice about which way to turn.
	if (bp[0] && bp[1]) {
	    if(rand()%2 > 0){
	      turnrate=turnrate_P;
	    }
	    else{
	      turnrate=turnrate_N;
	    }		
	}
      } 
      else {
	  turnrate = 0;   
	  speed=speed_P;
      }     

      // What did we decide to do?
      std::cout << "Speed: " << speed << std::endl;      
      std::cout << "Turn rate: " << turnrate << std::endl << std::endl;

      // Send the motion commands that we decided on to the robot.
      pp.SetSpeed(speed, turnrate);  
    }
  
}


